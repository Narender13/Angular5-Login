
export class Employees {
    list?: EmployeeList[];
}

export class EmployeeList {
    firstName: string;
    lastName: string;
    emailAddress: string;
}

export class NavItem {
    navItem : NavItemList[];

}
export class NavItemList {
    link: string;
    urlF: string;

}