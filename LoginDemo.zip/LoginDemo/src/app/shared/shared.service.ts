import { Employees } from '../shared/shared.model';
import { NavItem } from '../shared/shared.model'


import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';



@Injectable()
export class SharedService {
    private _baseUrl = 'http://localhost:4200';
    private login$ = new Subject<any>();

    constructor(private http: HttpClient) { }

     checkLogin(): Observable<any> {
        return this.login$.asObservable();
    }
    setLogin(value:any) {
         this.login$.next(value);
    }
    public list(): Observable<Employees> {
        return this.http.get(this._baseUrl + '/mock.json').pipe(map(data => (data)));

    }
    public itemList(): Observable<any> {
        return this.http.get(this._baseUrl + '/mock.json').pipe(map(data => data));

    }
}