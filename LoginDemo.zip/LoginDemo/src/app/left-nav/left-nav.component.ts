import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared/shared.service';
import { Observable } from 'rxjs'
import { NavItem } from '../shared/shared.model'


@Component({
  selector: 'app-left-nav',
  templateUrl: './left-nav.component.html',
  styleUrls: ['./left-nav.component.css']
})
export class LeftNavComponent implements OnInit {
  itemList: Observable<NavItem>;
  login: any = '0';
  constructor(
    private _sharedService: SharedService
  ) { }

  ngOnInit() {
    this.listItem();
    this._sharedService.checkLogin().subscribe(data => this.login = data)
  }
  public listItem() {
    this.itemList = this._sharedService.itemList();
  }

}
