import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  loggedInStatus = localStorage.getItem('user') || false;
  constructor() { }
  setLoggedIn(value) {
    this.loggedInStatus = value;
    localStorage.setItem('user', 'true');
  }
  get loggingInStatus() {
    return JSON.parse(localStorage.getItem('user')) || this.loggedInStatus;
  }
}
