import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared/shared.service';
import { Observable } from 'rxjs';
import { Employees } from '../shared/shared.model'

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employeeList: Observable<Employees>;
  constructor(private _sharedService: SharedService) { }

  ngOnInit() {
    this.list();
  }

  public list() {
    this.employeeList = this._sharedService.list();
  }

}
