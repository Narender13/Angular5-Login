import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { SharedService } from '../shared/shared.service';
import { LoginService } from '../login.service';
import { AuthService } from '../auth.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  user: any;
  constructor(private _router: Router, 
    private fb: FormBuilder, 
    private _loginService: LoginService,
    private _auth : AuthService,
    private activate : ActivatedRoute,
    private s: SharedService
  ) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      user: '',
      password: '',
    });
    const routeParams = this._router.url;
    if(routeParams == '/login'){
      localStorage.removeItem('user');
      //this._sharedService.setLogin("0");
      this.s.setLogin("0");
    }
  }
  login() {
    const user = this.loginForm.get('user').value;
    const pass = this.loginForm.get('password').value;
    debugger;
    this.user = this._loginService.login({ 'user': user, 'password': pass })
    if(this.user.status){
      this._auth.setLoggedIn(true);
      this._router.navigateByUrl('/home')
    }
  }
}
