import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
import { HomeModule } from './home/home.module';
import { LoginComponent } from './login/login.component';
import { AppRoutingModule } from './app-routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { AuthGuard } from './auth.guard'



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    HomeModule,
    SharedModule,
    HomeModule,
    HttpClientModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers:[AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
