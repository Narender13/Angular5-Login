import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor() { }

  login(userDetails: any) {
    if (userDetails) {
      if (userDetails.user == 'admin' && userDetails.password == 'admin') {
        return {
          "status": true,
          "user": 'valid',
          "userName": 'Admin',
          "Email": "admin@gmaul.com"
        }
      } else{
        return {
          "status": false,
          "user": 'invalid',
        }
      }
    } else {
      return {
        "status": false,
        "user": 'User send as blank',
      }
    }


  }
}
